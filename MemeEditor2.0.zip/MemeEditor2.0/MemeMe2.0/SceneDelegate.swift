//
//  SceneDelegate.swift
//  MemeMe2.0
//
//  Created by Aye Nyein Nyein Su on 17/05/2023.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?


}

