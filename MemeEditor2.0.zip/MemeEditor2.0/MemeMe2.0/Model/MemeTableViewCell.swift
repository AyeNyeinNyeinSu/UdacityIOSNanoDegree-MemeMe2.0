//
//  MemeTableViewCell.swift
//  MemeMe2.0
//
//  Created by Aye Nyein Nyein Su on 17/05/2023.
//

import UIKit

class MemeTableViewCell: UITableViewCell {

    @IBOutlet weak var sentMemeImage: UIImageView!
    @IBOutlet weak var sentMemeLabel: UILabel!

}
